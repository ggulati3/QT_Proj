#include "gametwo.h"

/* constructor of game 2; this is a placeholder class for the second game
 * @param N/A
 * @return N/A
 * */
gametwo::gametwo()
{
    layoutt->addWidget(back_button);
    layoutt->addWidget(win_game_button);
    this->setLayout(layoutt);
}

/* destructor of game 2; this is a placeholder class for the second game
 * @param N/A
 * @return N/A
 * */
gametwo::~gametwo(){
}
