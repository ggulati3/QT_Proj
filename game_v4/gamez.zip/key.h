#ifndef KEY_H
#define KEY_H

#include <QLabel>

class key: public QLabel
{
public:
    key();//default constructor, creates key image
};

#endif // KEY_H
