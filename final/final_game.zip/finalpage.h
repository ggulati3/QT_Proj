#ifndef FINALPAGE_H
#define FINALPAGE_H
#include <QLabel>

class finalpage: public QLabel
{
public:
    finalpage();//default constructor - creates a trophy image
};

#endif // FINALPAGE_H
