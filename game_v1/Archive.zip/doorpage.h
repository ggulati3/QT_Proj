#ifndef DOORPAGE_H
#define DOORPAGE_H
#include "door.h"
#include <QGridLayout>
class doorPage : public QWidget
{
public:
    doorPage();

public slots:

};

#endif // DOORPAGE_H
