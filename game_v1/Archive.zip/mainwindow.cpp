#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStackedWidget>
#include <QGridLayout>
#include "door.h"
#include "doorpage.h"
#include "namepage.h"
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
      ui->setupUi(this);

      QWidget* secondWindow = new doorPage;


      QWidget* check = new QWidget;
      QLabel* label = new QLabel("hello");
      QHBoxLayout* layoutt = new QHBoxLayout;
      layoutt->addWidget(label);
      check->setLayout(layoutt);

      QStackedWidget* stackWidget =   new QStackedWidget;

      stackWidget->addWidget(secondWindow); // doors - index 0
      stackWidget->addWidget(check); //hello - index 1

      stackWidget->setCurrentIndex(0);

      this->setCentralWidget(stackWidget);
}

MainWindow::~MainWindow()
{
    delete ui;
}
