#ifndef NAMEPAGE_H
#define NAMEPAGE_H
#include <QPushButton>
#include <QHBoxLayout>

class NamePage : public QWidget
{
public:
    NamePage();
};

#endif // NAMEPAGE_H
